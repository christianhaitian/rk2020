/usr/local/bin/retroarch -L /home/odroid/.config/retroarch/cores/ecwolf_libretro.so /roms/ports/ecwolf/WOLF3D.EXE
