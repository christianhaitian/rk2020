/usr/local/bin/retroarch -L /home/odroid/.config/retroarch/cores/xrick_libretro.so /roms/ports/xrick/data.zip
