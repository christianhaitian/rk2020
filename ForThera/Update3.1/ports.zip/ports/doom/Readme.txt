not zip files
Doom.wad   (rom)
prboom.wad  (bios)
This files are require inside this directory (doom) for port to work.
