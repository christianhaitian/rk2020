/usr/local/bin/retroarch -L /home/odroid/.config/retroarch/cores/nxengine_libretro.so /roms/ports/cavestory/Doukutsu.exe
