/usr/local/bin/retroarch -L /home/odroid/.config/retroarch/cores/cannonball_libretro.so /roms/ports/cannonball/epr-10187.88
