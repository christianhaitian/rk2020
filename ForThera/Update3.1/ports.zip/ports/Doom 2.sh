/usr/local/bin/retroarch -L /home/odroid/.config/retroarch/cores/prboom_libretro.so /roms/ports/doom2/Doom2.wad
